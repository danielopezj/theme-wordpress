<?php get_header(); ?>
<div class="contenedor">
	<h1>Este es el body</h1>

</div>

<?php get_footer(); ?>
