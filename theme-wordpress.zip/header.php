<!DOCTYPE html>
<html>
<head>
	<title><?php bloginfo( 'author' ); ?></title>
	<link rel="stylesheet"  href="<?php bloginfo(stylesheet_url); ?>">

	<?php wp_head(); ?>
</head>
<body>
<header>
	<h1>Esto es un header</h1>
</header>