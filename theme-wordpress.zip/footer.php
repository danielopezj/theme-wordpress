<footer>
	<h1>Este es el footer</h1>
</footer>

<?php get_footer(); ?>

</body>
</html>